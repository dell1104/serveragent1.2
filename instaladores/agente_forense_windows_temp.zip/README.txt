# Agente Forense - Instalador Windows

## Instalación
1. Extraer este archivo ZIP
2. Ejecutar ForensicAgent-Windows-Installer.exe como administrador
3. Seguir las instrucciones en pantalla

## Uso
- El agente se instalará en: C:\Program Files\AgenteForense
- Se creará un acceso directo en el escritorio
- Ejecutar desde el acceso directo o desde el menú inicio

## Soporte
Para soporte técnico, contactar al administrador del sistema.

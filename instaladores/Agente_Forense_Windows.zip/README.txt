# Agente Forense - Instalador Windows

## Instalación
1. Extraer este archivo ZIP
2. Hacer clic derecho en "Instalar_Agente_Forense.bat"
3. Seleccionar "Ejecutar como administrador"
4. Seguir las instrucciones en pantalla

## Requisitos
- Windows 10/11
- Permisos de administrador
- Conexión a internet

## Uso
- El agente se instalará en: C:\Program Files\AgenteForense
- Se creará un acceso directo en el escritorio
- Se agregará una entrada en el menú inicio
- Para iniciar: usar el acceso directo o ejecutar desde el menú inicio

## Desinstalación
- Ejecutar "desinstalar.bat" desde la carpeta de instalación
- O eliminar manualmente la carpeta C:\Program Files\AgenteForense

## Soporte
Para soporte técnico, contactar al administrador del sistema.

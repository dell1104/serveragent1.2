#!/usr/bin/env python3
"""
Agente Windows para Adquisición Forense
Se ejecuta en cada máquina Windows con acceso a discos físicos
"""

import os
import sys
import time
import hashlib
import threading
import subprocess
import platform
import json
import requests
from pathlib import Path
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Configuración del agente
AGENT_CONFIG = {
    'version': '1.0.0',
    'name': 'Agente Forense Windows',
    'port': 5001,
    'api_key': 'forensic_agent_2024',  # En producción, usar variable de entorno
    'max_file_size': 1024 * 1024 * 1024 * 100,  # 100GB máximo
    'supported_formats': ['DD', 'E01', 'IMG'],
    'output_dir': 'C:\\evidencias_forenses'
}

# Verificar formatos disponibles
def check_available_formats():
    """Verifica qué formatos están disponibles"""
    formats = {
        'DD': True,  # Siempre disponible
        'IMG': True,  # Siempre disponible
        'E01': False,  # Necesita ewfacquire
        'AFF4': False  # No disponible en Python 3.13
    }
    
    # Verificar ewfacquire
    try:
        subprocess.run(['ewfacquire', '--version'], capture_output=True, timeout=5)
        formats['E01'] = True
    except:
        pass
    
    # AFF4 no disponible en Python 3.13
    # Se usa el stack forense para AFF4
    
    return formats

# Obtener formatos disponibles
AVAILABLE_FORMATS = check_available_formats()

# Estado global del agente
agent_state = {
    'status': 'ready',
    'current_operation': None,
    'progress': 0,
    'last_activity': datetime.now().isoformat()
}

def validate_api_key():
    """Valida la API key en las requests"""
    api_key = request.headers.get('Authorization', '').replace('Bearer ', '')
    return api_key == AGENT_CONFIG['api_key']

def get_device_info(device_path):
    """Obtiene información detallada del dispositivo"""
    try:
        if platform.system() == "Windows":
            # Usar wmic para obtener información del disco
            result = subprocess.run([
                'wmic', 'diskdrive', 'where', f'DeviceID="{device_path}"',
                'get', 'Model,Size,InterfaceType,SerialNumber,Status', '/format:csv'
            ], capture_output=True, text=True, encoding='utf-8')
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                for line in lines[1:]:
                    if line.strip() and ',' in line:
                        parts = line.split(',')
                        if len(parts) >= 6:
                            return {
                                'model': parts[2].strip(),
                                'size': parts[3].strip(),
                                'interface': parts[4].strip(),
                                'serial': parts[5].strip(),
                                'status': parts[6].strip() if len(parts) > 6 else 'Unknown'
                            }
    except Exception as e:
        logger.error(f"Error obteniendo info del dispositivo: {e}")
    
    return {'model': 'Unknown', 'size': '0', 'interface': 'Unknown', 'serial': 'Unknown', 'status': 'Unknown'}

def calculate_hash(file_path, algorithm='md5'):
    """Calcula hash de un archivo"""
    hash_obj = hashlib.new(algorithm)
    with open(file_path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hash_obj.update(chunk)
    return hash_obj.hexdigest()

def acquire_dd_image(device_path, output_path, progress_callback=None):
    """Adquiere imagen DD usando Python puro"""
    try:
        device_size = os.path.getsize(device_path)
        bytes_read = 0
        
        with open(device_path, 'rb') as device:
            with open(output_path, 'wb') as output:
                while bytes_read < device_size:
                    chunk = device.read(1024 * 1024)  # 1MB chunks
                    if not chunk:
                        break
                    
                    output.write(chunk)
                    bytes_read += len(chunk)
                    
                    if progress_callback:
                        progress = int((bytes_read / device_size) * 100)
                        progress_callback(progress, f"Adquiriendo DD: {bytes_read // (1024*1024)} MB")
        
        return True
    except Exception as e:
        logger.error(f"Error en adquisición DD: {e}")
        return False

def acquire_e01_image(device_path, output_path, progress_callback=None):
    """Adquiere imagen E01 usando ewfacquire"""
    try:
        cmd = ['ewfacquire', '-t', output_path, device_path]
        
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            universal_newlines=True
        )
        
        while process.poll() is None:
            line = process.stdout.readline()
            if line and progress_callback:
                # Parsear progreso de ewfacquire
                if 'Progress:' in line or '%' in line:
                    progress_callback(50, f"E01: {line.strip()}")
            time.sleep(0.1)
        
        stdout, stderr = process.communicate()
        
        if process.returncode == 0:
            return True
        else:
            logger.error(f"Error ewfacquire: {stderr}")
            return False
            
    except FileNotFoundError:
        logger.error("ewfacquire no está instalado")
        return False
    except Exception as e:
        logger.error(f"Error en adquisición E01: {e}")
        return False

def acquire_aff4_image(device_path, output_path, progress_callback=None):
    """AFF4 no disponible en Python 3.13 - usar stack forense"""
    logger.error("AFF4 no disponible en Python 3.13")
    logger.error("Para usar AFF4, use el stack forense (Python 3.9)")
    return False

# ==================== RUTAS API ====================

@app.route('/status', methods=['GET'])
def get_status():
    """Obtiene el estado del agente"""
    if not validate_api_key():
        return jsonify({'error': 'API key inválida'}), 401
    
    return jsonify({
        'status': 'success',
        'agent': {
            'name': AGENT_CONFIG['name'],
            'version': AGENT_CONFIG['version'],
            'status': agent_state['status'],
            'current_operation': agent_state['current_operation'],
            'progress': agent_state['progress'],
            'last_activity': agent_state['last_activity'],
            'supported_formats': AGENT_CONFIG['supported_formats'],
            'available_formats': AVAILABLE_FORMATS
        }
    })

@app.route('/disks', methods=['GET'])
def list_disks():
    """Lista los discos disponibles"""
    if not validate_api_key():
        return jsonify({'error': 'API key inválida'}), 401
    
    try:
        dispositivos = []
        
        if platform.system() == "Windows":
            result = subprocess.run([
                'wmic', 'diskdrive', 'get', 'DeviceID,Model,Size,InterfaceType,SerialNumber', '/format:csv'
            ], capture_output=True, text=True, encoding='utf-8', timeout=10)
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                for line in lines[1:]:
                    if line.strip() and ',' in line:
                        parts = line.split(',')
                        if len(parts) >= 6:
                            device_id = parts[1].strip()
                            model = parts[2].strip()
                            size = parts[3].strip()
                            interface = parts[4].strip()
                            serial = parts[5].strip()
                            
                            if device_id and model:
                                try:
                                    size_gb = int(size) // (1024**3) if size.isdigit() else 0
                                    size_str = f"{size_gb} GB" if size_gb > 0 else "N/A"
                                except:
                                    size_str = "N/A"
                                
                                dispositivos.append({
                                    'device_id': device_id,
                                    'model': model,
                                    'size': size_str,
                                    'size_bytes': int(size) if size.isdigit() else 0,
                                    'interface': interface,
                                    'serial': serial,
                                    'type': 'HDD' if 'SATA' in interface or 'IDE' in interface else 'USB'
                                })
        
        return jsonify({
            'status': 'success',
            'disks': dispositivos,
            'count': len(dispositivos)
        })
        
    except Exception as e:
        logger.error(f"Error listando discos: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/acquire', methods=['POST'])
def acquire_image():
    """Inicia la adquisición de una imagen forense"""
    if not validate_api_key():
        return jsonify({'error': 'API key inválida'}), 401
    
    try:
        data = request.json
        device_id = data.get('device_id')
        format_type = data.get('format', 'DD').upper()
        output_name = data.get('output_name', f"imagen_{int(time.time())}")
        case_id = data.get('case_id', 'unknown')
        
        if not device_id:
            return jsonify({'status': 'error', 'error': 'device_id es requerido'}), 400
        
        if format_type not in AGENT_CONFIG['supported_formats']:
            return jsonify({'status': 'error', 'error': f'Formato {format_type} no soportado'}), 400
        
        # Crear directorio de salida
        output_dir = Path(AGENT_CONFIG['output_dir']) / case_id
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Determinar extensión del archivo
        extensions = {'DD': 'dd', 'IMG': 'img', 'E01': 'E01', 'AFF4': 'aff4'}
        extension = extensions.get(format_type, 'dd')
        output_path = output_dir / f"{output_name}.{extension}"
        
        # Actualizar estado
        agent_state['status'] = 'acquiring'
        agent_state['current_operation'] = {
            'device_id': device_id,
            'format': format_type,
            'output_path': str(output_path),
            'start_time': datetime.now().isoformat()
        }
        agent_state['progress'] = 0
        
        def progress_callback(progress, message):
            agent_state['progress'] = progress
            agent_state['last_activity'] = datetime.now().isoformat()
            logger.info(f"Progreso: {progress}% - {message}")
        
        # Ejecutar adquisición en hilo separado
        def acquire_thread():
            try:
                success = False
                
                if format_type in ['DD', 'IMG']:
                    success = acquire_dd_image(device_id, str(output_path), progress_callback)
                elif format_type == 'E01':
                    success = acquire_e01_image(device_id, str(output_path), progress_callback)
                elif format_type == 'AFF4':
                    success = acquire_aff4_image(device_id, str(output_path), progress_callback)
                
                if success:
                    # Calcular hashes
                    md5_hash = calculate_hash(str(output_path), 'md5')
                    sha1_hash = calculate_hash(str(output_path), 'sha1')
                    sha256_hash = calculate_hash(str(output_path), 'sha256')
                    
                    # Obtener tamaño final
                    file_size = os.path.getsize(str(output_path))
                    
                    agent_state['status'] = 'completed'
                    agent_state['current_operation']['end_time'] = datetime.now().isoformat()
                    agent_state['current_operation']['success'] = True
                    agent_state['current_operation']['file_size'] = file_size
                    agent_state['current_operation']['hashes'] = {
                        'md5': md5_hash,
                        'sha1': sha1_hash,
                        'sha256': sha256_hash
                    }
                    
                    logger.info(f"Adquisición completada: {output_path}")
                else:
                    agent_state['status'] = 'error'
                    agent_state['current_operation']['end_time'] = datetime.now().isoformat()
                    agent_state['current_operation']['success'] = False
                    agent_state['current_operation']['error'] = 'Error durante la adquisición'
                    
            except Exception as e:
                agent_state['status'] = 'error'
                agent_state['current_operation']['end_time'] = datetime.now().isoformat()
                agent_state['current_operation']['success'] = False
                agent_state['current_operation']['error'] = str(e)
                logger.error(f"Error en adquisición: {e}")
        
        # Iniciar hilo de adquisición
        thread = threading.Thread(target=acquire_thread)
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'status': 'success',
            'message': 'Adquisición iniciada',
            'operation_id': f"{case_id}_{output_name}",
            'output_path': str(output_path)
        })
        
    except Exception as e:
        logger.error(f"Error iniciando adquisición: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/acquire/<operation_id>/status', methods=['GET'])
def get_acquisition_status(operation_id):
    """Obtiene el estado de una adquisición en progreso"""
    if not validate_api_key():
        return jsonify({'error': 'API key inválida'}), 401
    
    return jsonify({
        'status': 'success',
        'operation': agent_state['current_operation'],
        'progress': agent_state['progress'],
        'agent_status': agent_state['status']
    })

@app.route('/acquire/<operation_id>/cancel', methods=['POST'])
def cancel_acquisition(operation_id):
    """Cancela una adquisición en progreso"""
    if not validate_api_key():
        return jsonify({'error': 'API key inválida'}), 401
    
    if agent_state['status'] == 'acquiring':
        agent_state['status'] = 'cancelled'
        agent_state['current_operation']['end_time'] = datetime.now().isoformat()
        agent_state['current_operation']['success'] = False
        agent_state['current_operation']['error'] = 'Cancelado por el usuario'
        
        return jsonify({'status': 'success', 'message': 'Adquisición cancelada'})
    else:
        return jsonify({'status': 'error', 'error': 'No hay adquisición en progreso'}), 400

@app.route('/logs', methods=['GET'])
def get_logs():
    """Obtiene los logs del agente"""
    if not validate_api_key():
        return jsonify({'error': 'API key inválida'}), 401
    
    # En una implementación real, leerías de un archivo de log
    logs = [
        {
            'timestamp': datetime.now().isoformat(),
            'level': 'INFO',
            'message': f"Agente {AGENT_CONFIG['name']} v{AGENT_CONFIG['version']} ejecutándose"
        }
    ]
    
    return jsonify({
        'status': 'success',
        'logs': logs
    })

if __name__ == '__main__':
    # Crear directorio de salida
    Path(AGENT_CONFIG['output_dir']).mkdir(parents=True, exist_ok=True)
    
    print(f"🚀 Iniciando {AGENT_CONFIG['name']} v{AGENT_CONFIG['version']}")
    print(f"📁 Directorio de salida: {AGENT_CONFIG['output_dir']}")
    print(f"🔑 API Key: {AGENT_CONFIG['api_key']}")
    print(f"🌐 Servidor en: http://0.0.0.0:{AGENT_CONFIG['port']}")
    
    app.run(host='0.0.0.0', port=AGENT_CONFIG['port'], debug=False)

# test_autostart.ps1 - Probar Configuraciones de Inicio Automático

Write-Host "========================================" -ForegroundColor Green
Write-Host "  Probador de Inicio Automático" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

# Verificar si se ejecuta como administrador
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "❌ ERROR: Este script requiere permisos de administrador." -ForegroundColor Red
    Write-Host "Para probar el inicio automático, ejecute PowerShell como administrador." -ForegroundColor Red
    Write-Host ""
    Write-Host "Comando:" -ForegroundColor Cyan
    Write-Host "Set-ExecutionPolicy Bypass -Scope Process; .$($MyInvocation.MyCommand.Definition)" -ForegroundColor Cyan
    exit 1
}

Write-Host "✅ Ejecutándose como administrador" -ForegroundColor Green
Write-Host ""

# ==================== VERIFICAR TAREA PROGRAMADA ====================
Write-Host "🔍 Verificando Tarea Programada..." -ForegroundColor Cyan
try {
    $task = Get-ScheduledTask -TaskName "ForensicAgentStartup" -ErrorAction SilentlyContinue
    if ($task) {
        Write-Host "✅ Tarea Programada encontrada" -ForegroundColor Green
        Write-Host "  📋 Nombre: $($task.TaskName)" -ForegroundColor DarkGray
        Write-Host "  📊 Estado: $($task.State)" -ForegroundColor DarkGray
        Write-Host "  🚀 Habilitada: $($task.Settings.Enabled)" -ForegroundColor DarkGray
        
        # Verificar trigger
        $triggers = $task.Triggers
        if ($triggers) {
            Write-Host "  ⏰ Triggers:" -ForegroundColor DarkGray
            foreach ($trigger in $triggers) {
                Write-Host "    - $($trigger.CimClass.CimClassName): $($trigger.Enabled)" -ForegroundColor DarkGray
            }
        }
        
        # Verificar acción
        $actions = $task.Actions
        if ($actions) {
            Write-Host "  🎯 Acción:" -ForegroundColor DarkGray
            foreach ($action in $actions) {
                Write-Host "    - Ejecutar: $($action.Execute)" -ForegroundColor DarkGray
                Write-Host "    - Argumentos: $($action.Arguments)" -ForegroundColor DarkGray
                Write-Host "    - Directorio: $($action.WorkingDirectory)" -ForegroundColor DarkGray
            }
        }
    } else {
        Write-Host "❌ Tarea Programada no encontrada" -ForegroundColor Red
    }
} catch {
    Write-Host "❌ Error verificando Tarea Programada: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# ==================== VERIFICAR SERVICIO DE WINDOWS ====================
Write-Host "🔍 Verificando Servicio de Windows..." -ForegroundColor Cyan
try {
    $service = Get-Service -Name "ForensicAgent" -ErrorAction SilentlyContinue
    if ($service) {
        Write-Host "✅ Servicio de Windows encontrado" -ForegroundColor Green
        Write-Host "  📋 Nombre: $($service.Name)" -ForegroundColor DarkGray
        Write-Host "  📊 Estado: $($service.Status)" -ForegroundColor DarkGray
        Write-Host "  🚀 Tipo de Inicio: $($service.StartType)" -ForegroundColor DarkGray
        Write-Host "  📁 Servicio: $($service.ServiceName)" -ForegroundColor DarkGray
        
        # Verificar configuración del servicio
        $serviceConfig = Get-WmiObject -Class Win32_Service -Filter "Name='ForensicAgent'"
        if ($serviceConfig) {
            Write-Host "  🔧 Configuración:" -ForegroundColor DarkGray
            Write-Host "    - Ruta: $($serviceConfig.PathName)" -ForegroundColor DarkGray
            Write-Host "    - Usuario: $($serviceConfig.StartName)" -ForegroundColor DarkGray
            Write-Host "    - Descripción: $($serviceConfig.Description)" -ForegroundColor DarkGray
        }
    } else {
        Write-Host "❌ Servicio de Windows no encontrado" -ForegroundColor Red
    }
} catch {
    Write-Host "❌ Error verificando Servicio de Windows: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# ==================== VERIFICAR ARCHIVOS DE CONFIGURACIÓN ====================
Write-Host "🔍 Verificando archivos de configuración..." -ForegroundColor Cyan
$AGENT_DIR = (Get-Item -Path $PSScriptRoot).FullName
$AGENT_SCRIPT = Join-Path $AGENT_DIR "agent.py"
$AGENT_BAT = Join-Path $AGENT_DIR "start_agent.bat"

if (Test-Path $AGENT_SCRIPT) {
    Write-Host "✅ agent.py encontrado" -ForegroundColor Green
} else {
    Write-Host "❌ agent.py no encontrado" -ForegroundColor Red
}

if (Test-Path $AGENT_BAT) {
    Write-Host "✅ start_agent.bat encontrado" -ForegroundColor Green
    Write-Host "  📁 Contenido:" -ForegroundColor DarkGray
    Get-Content $AGENT_BAT | ForEach-Object { Write-Host "    $_" -ForegroundColor DarkGray }
} else {
    Write-Host "❌ start_agent.bat no encontrado" -ForegroundColor Red
}
Write-Host ""

# ==================== PROBAR INICIO DEL AGENTE ====================
Write-Host "🧪 Probando inicio del agente..." -ForegroundColor Cyan
try {
    # Verificar si el agente ya está ejecutándose
    $processes = Get-Process -Name "python" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*agent.py*" }
    if ($processes) {
        Write-Host "✅ Agente ya está ejecutándose" -ForegroundColor Green
        Write-Host "  📊 PID: $($processes.Id)" -ForegroundColor DarkGray
        Write-Host "  🕒 Tiempo de inicio: $($processes.StartTime)" -ForegroundColor DarkGray
    } else {
        Write-Host "ℹ️  Agente no está ejecutándose" -ForegroundColor Yellow
        Write-Host "  💡 Para iniciarlo: python agent.py" -ForegroundColor Cyan
    }
} catch {
    Write-Host "❌ Error verificando procesos: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# ==================== PROBAR CONECTIVIDAD ====================
Write-Host "🌐 Probando conectividad del agente..." -ForegroundColor Cyan
try {
    $response = Invoke-WebRequest -Uri "http://localhost:5001/status" -Headers @{"Authorization" = "Bearer forensic_agent_2024"} -TimeoutSec 5
    if ($response.StatusCode -eq 200) {
        Write-Host "✅ Agente responde correctamente" -ForegroundColor Green
        $data = $response.Content | ConvertFrom-Json
        Write-Host "  📋 Estado: $($data.agent.status)" -ForegroundColor DarkGray
        Write-Host "  🔧 Versión: $($data.agent.version)" -ForegroundColor DarkGray
        Write-Host "  📊 Progreso: $($data.agent.progress)%" -ForegroundColor DarkGray
    } else {
        Write-Host "❌ Agente no responde (Status: $($response.StatusCode))" -ForegroundColor Red
    }
} catch {
    Write-Host "❌ Error conectando con agente: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "  💡 Asegúrese de que el agente esté ejecutándose" -ForegroundColor Cyan
}
Write-Host ""

# ==================== RESUMEN ====================
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Resumen de Verificación" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

# Contar configuraciones activas
$taskActive = $false
$serviceActive = $false

try {
    $task = Get-ScheduledTask -TaskName "ForensicAgentStartup" -ErrorAction SilentlyContinue
    $taskActive = $task -ne $null
} catch { }

try {
    $service = Get-Service -Name "ForensicAgent" -ErrorAction SilentlyContinue
    $serviceActive = $service -ne $null
} catch { }

if ($taskActive -and $serviceActive) {
    Write-Host "✅ CONFIGURACIÓN COMPLETA: Tarea Programada + Servicio" -ForegroundColor Green
} elseif ($taskActive) {
    Write-Host "✅ CONFIGURACIÓN PARCIAL: Solo Tarea Programada" -ForegroundColor Yellow
} elseif ($serviceActive) {
    Write-Host "✅ CONFIGURACIÓN PARCIAL: Solo Servicio" -ForegroundColor Yellow
} else {
    Write-Host "❌ CONFIGURACIÓN INCOMPLETA: No hay inicio automático" -ForegroundColor Red
}

Write-Host ""
Write-Host "📋 RECOMENDACIONES:" -ForegroundColor Cyan
if (-not $taskActive -and -not $serviceActive) {
    Write-Host "• Ejecutar: .\configure_autostart.ps1 -Mode both" -ForegroundColor White
} elseif (-not $taskActive) {
    Write-Host "• Agregar Tarea Programada: .\configure_autostart.ps1 -Mode task" -ForegroundColor White
} elseif (-not $serviceActive) {
    Write-Host "• Agregar Servicio: .\configure_autostart.ps1 -Mode service" -ForegroundColor White
} else {
    Write-Host "• Configuración óptima detectada" -ForegroundColor Green
}

Write-Host ""
Write-Host "🔧 COMANDOS ÚTILES:" -ForegroundColor Cyan
Write-Host "• Ver tareas: Get-ScheduledTask -TaskName 'ForensicAgentStartup'" -ForegroundColor White
Write-Host "• Ver servicios: Get-Service -Name 'ForensicAgent'" -ForegroundColor White
Write-Host "• Iniciar servicio: Start-Service -Name 'ForensicAgent'" -ForegroundColor White
Write-Host "• Detener servicio: Stop-Service -Name 'ForensicAgent'" -ForegroundColor White
Write-Host "• Probar agente: python ..\test_agente_windows.py" -ForegroundColor White
Write-Host ""

Read-Host "Presione Enter para salir"

# configure_autostart.ps1 - Configurar Inicio Automático del Agente Forense

param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("task", "service", "both", "remove")]
    [string]$Mode = "both",
    
    [Parameter(Mandatory=$false)]
    [string]$User = $env:USERNAME
)

# Configuración
$AGENT_DIR = (Get-Item -Path $PSScriptRoot).FullName
$AGENT_SCRIPT = Join-Path $AGENT_DIR "agent.py"
$AGENT_BAT = Join-Path $AGENT_DIR "start_agent.bat"
$SERVICE_NAME = "ForensicAgent"
$TASK_NAME = "ForensicAgentStartup"

Write-Host "========================================" -ForegroundColor Green
Write-Host "  Configurador de Inicio Automático" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

# Verificar si se ejecuta como administrador
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "❌ ERROR: Este script requiere permisos de administrador." -ForegroundColor Red
    Write-Host "Para configurar el inicio automático, ejecute PowerShell como administrador." -ForegroundColor Red
    Write-Host ""
    Write-Host "Comando:" -ForegroundColor Cyan
    Write-Host "Set-ExecutionPolicy Bypass -Scope Process; .$($MyInvocation.MyCommand.Definition)" -ForegroundColor Cyan
    exit 1
}

# Verificar que el agente existe
if (-not (Test-Path $AGENT_SCRIPT)) {
    Write-Host "❌ ERROR: No se encontró el archivo del agente: $AGENT_SCRIPT" -ForegroundColor Red
    exit 1
}

# Crear script de inicio si no existe
if (-not (Test-Path $AGENT_BAT)) {
    Write-Host "📝 Creando script de inicio..." -ForegroundColor Cyan
    @"
@echo off
cd /d "$AGENT_DIR"
python "$AGENT_SCRIPT"
"@ | Set-Content -Path $AGENT_BAT -Force
    Write-Host "✅ Script de inicio creado: $AGENT_BAT" -ForegroundColor Green
}

# ==================== CONFIGURAR TAREA PROGRAMADA ====================
function Configure-ScheduledTask {
    Write-Host "📅 Configurando Tarea Programada..." -ForegroundColor Cyan
    
    # Eliminar tarea existente si existe
    try {
        Unregister-ScheduledTask -TaskName $TASK_NAME -Confirm:$false -ErrorAction SilentlyContinue
        Write-Host "  ✅ Tarea existente eliminada" -ForegroundColor Green
    } catch {
        Write-Host "  ℹ️  No había tarea existente" -ForegroundColor DarkGray
    }
    
    # Crear nueva tarea
    $Action = New-ScheduledTaskAction -Execute $AGENT_BAT -WorkingDirectory $AGENT_DIR
    $Trigger = New-ScheduledTaskTrigger -AtStartup
    $Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable
    $Principal = New-ScheduledTaskPrincipal -UserId $User -LogonType InteractiveToken
    
    try {
        Register-ScheduledTask -TaskName $TASK_NAME -Action $Action -Trigger $Trigger -Settings $Settings -Principal $Principal -Description "Inicia el Agente Forense automáticamente al arrancar el sistema"
        Write-Host "✅ Tarea Programada configurada correctamente" -ForegroundColor Green
        Write-Host "  📋 Nombre: $TASK_NAME" -ForegroundColor DarkGray
        Write-Host "  👤 Usuario: $User" -ForegroundColor DarkGray
        Write-Host "  🚀 Inicio: Al arrancar el sistema" -ForegroundColor DarkGray
    } catch {
        Write-Host "❌ Error configurando Tarea Programada: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
    
    return $true
}

# ==================== CONFIGURAR SERVICIO DE WINDOWS ====================
function Configure-WindowsService {
    Write-Host "🔧 Configurando Servicio de Windows..." -ForegroundColor Cyan
    
    # Eliminar servicio existente si existe
    try {
        $service = Get-Service -Name $SERVICE_NAME -ErrorAction SilentlyContinue
        if ($service) {
            Stop-Service -Name $SERVICE_NAME -Force -ErrorAction SilentlyContinue
            sc.exe delete $SERVICE_NAME
            Write-Host "  ✅ Servicio existente eliminado" -ForegroundColor Green
        }
    } catch {
        Write-Host "  ℹ️  No había servicio existente" -ForegroundColor DarkGray
    }
    
    # Crear servicio usando sc.exe
    try {
        $result = sc.exe create $SERVICE_NAME binPath= "$AGENT_BAT" DisplayName= "Agente Forense" start= auto
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✅ Servicio de Windows creado correctamente" -ForegroundColor Green
            Write-Host "  📋 Nombre: $SERVICE_NAME" -ForegroundColor DarkGray
            Write-Host "  🚀 Inicio: Automático" -ForegroundColor DarkGray
            Write-Host "  📁 Ruta: $AGENT_BAT" -ForegroundColor DarkGray
        } else {
            Write-Host "❌ Error creando servicio: $result" -ForegroundColor Red
            return $false
        }
    } catch {
        Write-Host "❌ Error configurando Servicio de Windows: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
    
    return $true
}

# ==================== ELIMINAR CONFIGURACIONES ====================
function Remove-AutoStart {
    Write-Host "🗑️ Eliminando configuraciones de inicio automático..." -ForegroundColor Cyan
    
    # Eliminar Tarea Programada
    try {
        Unregister-ScheduledTask -TaskName $TASK_NAME -Confirm:$false -ErrorAction SilentlyContinue
        Write-Host "✅ Tarea Programada eliminada" -ForegroundColor Green
    } catch {
        Write-Host "ℹ️  No había Tarea Programada configurada" -ForegroundColor DarkGray
    }
    
    # Eliminar Servicio
    try {
        $service = Get-Service -Name $SERVICE_NAME -ErrorAction SilentlyContinue
        if ($service) {
            Stop-Service -Name $SERVICE_NAME -Force -ErrorAction SilentlyContinue
            sc.exe delete $SERVICE_NAME
            Write-Host "✅ Servicio de Windows eliminado" -ForegroundColor Green
        } else {
            Write-Host "ℹ️  No había Servicio configurado" -ForegroundColor DarkGray
        }
    } catch {
        Write-Host "ℹ️  No había Servicio configurado" -ForegroundColor DarkGray
    }
}

# ==================== VERIFICAR CONFIGURACIONES ====================
function Test-AutoStart {
    Write-Host "🔍 Verificando configuraciones..." -ForegroundColor Cyan
    
    # Verificar Tarea Programada
    try {
        $task = Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
        if ($task) {
            Write-Host "✅ Tarea Programada: ACTIVA" -ForegroundColor Green
            Write-Host "  📋 Estado: $($task.State)" -ForegroundColor DarkGray
        } else {
            Write-Host "❌ Tarea Programada: NO CONFIGURADA" -ForegroundColor Red
        }
    } catch {
        Write-Host "❌ Tarea Programada: ERROR" -ForegroundColor Red
    }
    
    # Verificar Servicio
    try {
        $service = Get-Service -Name $SERVICE_NAME -ErrorAction SilentlyContinue
        if ($service) {
            Write-Host "✅ Servicio de Windows: ACTIVO" -ForegroundColor Green
            Write-Host "  📋 Estado: $($service.Status)" -ForegroundColor DarkGray
            Write-Host "  🚀 Tipo de Inicio: $($service.StartType)" -ForegroundColor DarkGray
        } else {
            Write-Host "❌ Servicio de Windows: NO CONFIGURADO" -ForegroundColor Red
        }
    } catch {
        Write-Host "❌ Servicio de Windows: ERROR" -ForegroundColor Red
    }
}

# ==================== EJECUTAR SEGÚN MODO ====================
switch ($Mode) {
    "task" {
        Write-Host "📅 Configurando solo Tarea Programada..." -ForegroundColor Yellow
        if (Configure-ScheduledTask) {
            Write-Host "✅ Configuración completada" -ForegroundColor Green
        }
    }
    "service" {
        Write-Host "🔧 Configurando solo Servicio de Windows..." -ForegroundColor Yellow
        if (Configure-WindowsService) {
            Write-Host "✅ Configuración completada" -ForegroundColor Green
        }
    }
    "both" {
        Write-Host "🚀 Configurando ambas opciones..." -ForegroundColor Yellow
        $taskSuccess = Configure-ScheduledTask
        $serviceSuccess = Configure-WindowsService
        
        if ($taskSuccess -and $serviceSuccess) {
            Write-Host "✅ Ambas configuraciones completadas" -ForegroundColor Green
        } elseif ($taskSuccess) {
            Write-Host "⚠️  Solo Tarea Programada configurada" -ForegroundColor Yellow
        } elseif ($serviceSuccess) {
            Write-Host "⚠️  Solo Servicio configurado" -ForegroundColor Yellow
        } else {
            Write-Host "❌ Error en ambas configuraciones" -ForegroundColor Red
        }
    }
    "remove" {
        Remove-AutoStart
        Write-Host "✅ Configuraciones eliminadas" -ForegroundColor Green
    }
}

# Verificar configuraciones finales
if ($Mode -ne "remove") {
    Write-Host ""
    Test-AutoStart
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Configuración Completada" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "📋 INFORMACIÓN IMPORTANTE:" -ForegroundColor Cyan
Write-Host "• El agente se iniciará automáticamente al arrancar el sistema" -ForegroundColor White
Write-Host "• Para verificar: Administrador de tareas → Pestaña 'Inicio'" -ForegroundColor White
Write-Host "• Para verificar: Servicios → 'Agente Forense'" -ForegroundColor White
Write-Host "• Para desinstalar: Ejecutar con -Mode remove" -ForegroundColor White
Write-Host ""
Write-Host "🔧 COMANDOS ÚTILES:" -ForegroundColor Cyan
Write-Host "• Ver tareas: Get-ScheduledTask -TaskName $TASK_NAME" -ForegroundColor White
Write-Host "• Ver servicios: Get-Service -Name $SERVICE_NAME" -ForegroundColor White
Write-Host "• Iniciar servicio: Start-Service -Name $SERVICE_NAME" -ForegroundColor White
Write-Host "• Detener servicio: Stop-Service -Name $SERVICE_NAME" -ForegroundColor White
Write-Host ""

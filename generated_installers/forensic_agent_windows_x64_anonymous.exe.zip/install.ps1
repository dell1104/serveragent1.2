# install.ps1 - Instalador Agente Forense Windows (PowerShell)

param(
    [switch]$SkipAdminCheck,
    [switch]$SkipTools,
    [switch]$SkipAutostart
)

# Configuración
$AGENT_DIR = (Get-Item -Path $PSScriptRoot).FullName
$EVIDENCE_DIR = "C:\evidencias_forenses"
$AGENT_SCRIPT = Join-Path $AGENT_DIR "agent.py"

Write-Host "========================================" -ForegroundColor Green
Write-Host "  Instalador Agente Forense Windows" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

# --- 1. Verificar permisos de administrador ---
if (-not $SkipAdminCheck) {
    Write-Host "🔍 Verificando permisos de administrador..." -ForegroundColor Cyan
    if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
        Write-Host "⚠️  ADVERTENCIA: No se está ejecutando como administrador" -ForegroundColor Yellow
        Write-Host "El agente necesita permisos de administrador para acceder a discos físicos." -ForegroundColor Yellow
        Write-Host ""
        $continue = Read-Host "¿Desea continuar de todos modos? (S/N)"
        if ($continue -ne "S" -and $continue -ne "s") {
            Write-Host ""
            Write-Host "Instalación cancelada." -ForegroundColor Red
            Write-Host "Para ejecutar como administrador: PowerShell → Ejecutar como administrador" -ForegroundColor Cyan
            exit 1
        }
    } else {
        Write-Host "✅ Ejecutándose como administrador" -ForegroundColor Green
    }
    Write-Host ""
}

# --- 2. Verificar Python ---
Write-Host "🔍 Verificando Python..." -ForegroundColor Cyan
try {
    $pythonVersion = (python --version 2>&1).Split(' ')[1]
    Write-Host "✅ Python detectado: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ ERROR: Python no está instalado." -ForegroundColor Red
    Write-Host "Instale Python 3.8+ desde https://python.org" -ForegroundColor Red
    exit 1
}
Write-Host ""

# --- 3. Crear directorio de evidencias ---
Write-Host "📁 Creando directorio de evidencias..." -ForegroundColor Cyan
if (-not (Test-Path $EVIDENCE_DIR)) {
    New-Item -Path $EVIDENCE_DIR -ItemType Directory -Force | Out-Null
    Write-Host "✅ Directorio $EVIDENCE_DIR creado" -ForegroundColor Green
} else {
    Write-Host "✅ Directorio $EVIDENCE_DIR ya existe" -ForegroundColor Green
}
Write-Host ""

# --- 4. Instalar dependencias Python ---
Write-Host "📦 Instalando dependencias Python..." -ForegroundColor Cyan
try {
    pip install --upgrade pip | Write-Host -ForegroundColor DarkGray
    pip install -r (Join-Path $AGENT_DIR "requirements.txt") | Write-Host -ForegroundColor DarkGray
    Write-Host "✅ Dependencias Python instaladas" -ForegroundColor Green
} catch {
    Write-Host "❌ ERROR: Error instalando dependencias Python." -ForegroundColor Red
    Write-Host "Intente ejecutar como administrador." -ForegroundColor Red
    exit 1
}
Write-Host ""

# --- 5. Instalar herramientas forenses (opcional) ---
if (-not $SkipTools) {
    Write-Host "🔧 Instalando herramientas forenses..." -ForegroundColor Cyan
    
    # Verificar Chocolatey
    try {
        choco --version > $null 2>&1
        Write-Host "  ✅ Chocolatey encontrado" -ForegroundColor Green
        
        # Instalar ewf-tools
        Write-Host "  📦 Instalando ewf-tools..." -ForegroundColor DarkCyan
        choco install ewf-tools -y | Write-Host -ForegroundColor DarkGray
        if ($LASTEXITCODE -eq 0) { Write-Host "  ✅ ewf-tools instalado" -ForegroundColor Green }
        
        # Instalar smartmontools
        Write-Host "  📦 Instalando smartmontools..." -ForegroundColor DarkCyan
        choco install smartmontools -y | Write-Host -ForegroundColor DarkGray
        if ($LASTEXITCODE -eq 0) { Write-Host "  ✅ smartmontools instalado" -ForegroundColor Green }
        
    } catch {
        Write-Host "  ⚠️  Chocolatey no disponible. Herramientas forenses no instaladas." -ForegroundColor Yellow
        Write-Host "  Para instalar manualmente: https://github.com/libyal/libewf/releases" -ForegroundColor Yellow
    }
    Write-Host ""
}

# --- 6. Configurar inicio automático (opcional) ---
if (-not $SkipAutostart) {
    Write-Host "🚀 Configurando inicio automático..." -ForegroundColor Cyan
    
    # Crear tarea programada
    $TaskName = "ForensicAgentStartup"
    $TaskAction = New-ScheduledTaskAction -Execute "python" -Argument $AGENT_SCRIPT -WorkingDirectory $AGENT_DIR
    $TaskTrigger = New-ScheduledTaskTrigger -AtStartup
    $TaskSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    $TaskPrincipal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
    
    try {
        # Eliminar tarea existente
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
        
        # Crear nueva tarea
        Register-ScheduledTask -TaskName $TaskName -Action $TaskAction -Trigger $TaskTrigger -Settings $TaskSettings -Principal $TaskPrincipal -Description "Inicia el Agente Forense automáticamente"
        
        Write-Host "✅ Inicio automático configurado" -ForegroundColor Green
    } catch {
        Write-Host "⚠️  Error configurando inicio automático: $($_.Exception.Message)" -ForegroundColor Yellow
    }
    Write-Host ""
}

# --- 7. Crear script de prueba ---
Write-Host "📝 Creando script de prueba..." -ForegroundColor Cyan
$TestScript = @"
@echo off
echo Probando Agente Forense Windows...
echo.
echo Verificando Python...
python --version
echo.
echo Verificando dependencias...
python -c "import flask; print('Flask: OK')"
python -c "import requests; print('Requests: OK')"
echo.
echo Iniciando agente de prueba...
echo Presione Ctrl+C para detener
echo.
python agent.py
"@
$TestScript | Set-Content -Path (Join-Path $AGENT_DIR "test.bat") -Force
Write-Host "✅ Script test.bat creado" -ForegroundColor Green
Write-Host ""

# --- 8. Resumen final ---
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Instalación Completada" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "✅ AGENTE WINDOWS LISTO PARA USAR" -ForegroundColor Green
Write-Host ""
Write-Host "Para ejecutar el agente:" -ForegroundColor White
Write-Host "  python agent.py" -ForegroundColor Gray
Write-Host ""
Write-Host "Para probar el agente:" -ForegroundColor White
Write-Host "  .\test.bat" -ForegroundColor Gray
Write-Host ""
Write-Host "El agente estará disponible en:" -ForegroundColor White
Write-Host "  http://localhost:5001" -ForegroundColor Gray
Write-Host ""
Write-Host "API Key: forensic_agent_2024" -ForegroundColor White
Write-Host ""
Write-Host "IMPORTANTE:" -ForegroundColor White
Write-Host "- Ejecute como administrador para acceso completo a discos" -ForegroundColor Gray
Write-Host "- Los archivos se guardan en: $EVIDENCE_DIR" -ForegroundColor Gray
Write-Host ""

# Preguntar si ejecutar el agente
$ejecutar = Read-Host "¿Desea ejecutar el agente ahora? (S/N)"
if ($ejecutar -eq "S" -or $ejecutar -eq "s") {
    Write-Host ""
    Write-Host "Iniciando agente..." -ForegroundColor Cyan
    Write-Host "Presione Ctrl+C para detener" -ForegroundColor Yellow
    Write-Host ""
    Start-Process python -ArgumentList $AGENT_SCRIPT -NoNewWindow
} else {
    Write-Host ""
    Write-Host "Para ejecutar más tarde: python agent.py" -ForegroundColor Gray
}
Write-Host ""

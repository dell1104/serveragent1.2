# Agente Forense - Instaladores

Este directorio contiene los instaladores para el agente forense en diferentes sistemas operativos.

## 📁 Archivos Incluidos

### Archivos Base
- `agent.py` - Script principal del agente
- `requirements.txt` - Dependencias Python
- `README.md` - Este archivo

### Instaladores Windows
- `install.ps1` - Instalador PowerShell completo (recomendado)
- `install.bat` - Instalador CMD básico
- `test.bat` - Probador del agente

### Instaladores Linux/macOS
- `install.sh` - Instalador shell completo
- `test.sh` - Probador del agente

## 🚀 Instalación Rápida

### Windows
```powershell
# Opción 1: PowerShell (recomendado)
.\install.ps1

# Opción 2: CMD
install.bat
```

### Linux/macOS
```bash
# Ejecutar como root
sudo ./install.sh
```

## 🧪 Probar Instalación

### Windows
```cmd
test.bat
```

### Linux/macOS
```bash
./test.sh
```

## 📋 Requisitos

- Python 3.8+
- pip
- Permisos de administrador/root (para acceso a discos)

## 🌐 Uso

Después de la instalación:

1. **Ejecutar el agente:**
   - Windows: `python agent.py`
   - Linux/macOS: `python3 agent.py`

2. **Acceder al agente:**
   - URL: `http://localhost:5001`
   - API Key: `forensic_agent_2024`

## 🔧 Características

- **Detección automática** de discos
- **Múltiples formatos** (DD, E01, AFF4, IMG)
- **Inicio automático** (opcional)
- **Herramientas forenses** (ewfacquire, smartctl)
- **Interfaz web** para monitoreo

## 📞 Soporte

Para problemas o dudas, consulte la documentación principal del sistema.